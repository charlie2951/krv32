// C program to test UART bootloader to load hex file into BRAM
// Incoming data from serial terminal PUTTY
//Received data (1-9) displayed on FPGA LED
//FPGA tested

#include <stdint.h>
#include <stdlib.h>

//BRAM mem location
#define BRAM_BASE   0x00000000
volatile uint32_t *bram = (uint32_t *)BRAM_BASE;
#define LED_ADDR 0x10000000   // starting addr of LED
#define LED_DATA *((volatile unsigned int *)(LED_ADDR ))
#define GPIO_DIR_ADDR 0x10000004   // starting addr of LED
#define GPIO_DIR *((volatile unsigned int *)(GPIO_DIR_ADDR ))
//********** UART Transmitter Register address map *******
#define UART_DATA_ADDR 0x20000000   // starting addr of UART DATA REG
#define UART_DATA *((volatile unsigned int *)(UART_DATA_ADDR ))
#define UART_CTRL_ADDR 0x20000004   // starting addr of UART CTRL REG
#define UART_CTRL *((volatile unsigned int *)(UART_CTRL_ADDR ))
#define UART_STATUS_ADDR 0x20000008   // starting addr of UART status REG
#define UART_STATUS *((volatile unsigned int *)(UART_STATUS_ADDR ))

//******UART Receiver Register address mapping**************
#define UART_RXDATA_ADDR 0x20000010   // starting addr of UART DATA REG
#define UART_RXDATA *((volatile unsigned int *)(UART_RXDATA_ADDR ))
#define UART_RXCTRL_ADDR 0x20000014   // starting addr of UART CTRL REG
#define UART_RXCTRL *((volatile unsigned int *)(UART_RXCTRL_ADDR ))
#define UART_RXSTATUS_ADDR 0x20000018   // starting addr of UART status REG
#define UART_RXSTATUS *((volatile unsigned int *)(UART_RXSTATUS_ADDR ))

// ** 7 segment display **//
/* Base Address defined in Verilog IP */
#define SEVEN_SEG_BASE    0x11000000
#define SEVEN_SEG_REG     (*(volatile uint32_t*)SEVEN_SEG_BASE)

/* Bit-field Definitions */
#define SS_MODE_HEX       (0 << 17)
#define SS_MODE_WORD      (1 << 17)
#define SS_DP_BIT         (1 << 16)
/* Special Word Codes (matching Verilog case statements) */
typedef enum {
    SS_WORD_NONE = 0,
    SS_WORD_DONE = 1,
    SS_WORD_BOOT = 2
} ss_word_t;

/* Function Prototypes */
void ss_write_hex(uint16_t value);
void ss_write_hex_dp(uint16_t value, uint8_t dp_on);
void ss_show_word(ss_word_t word);
void ss_clear(void);
// API Functions
void ss_show_word(ss_word_t word) {
    SEVEN_SEG_REG = SS_MODE_WORD | (uint32_t)word;
}

//
//ascii conversion
volatile uint8_t byte_to_hex_ascii(uint8_t data)
{
    volatile uint8_t low_nibble  = data & 0x0F;
    volatile uint8_t ascii;
   
    // Convert low nibble
    if (low_nibble >= 0 && low_nibble <10)
        ascii = 48 + low_nibble;
    else
        ascii = 55 + low_nibble;

   return ascii;
}
//Delay function
void delay(uint32_t cycles) {
  volatile uint32_t count = 0; // volatile to prevent compiler optimization

  while (count < cycles) {
    count++;
  }
}

//uart function to send a single character
void uart_send(uint8_t my_char)
{
    while(UART_STATUS==0) ;
           
    UART_DATA = my_char;
    UART_CTRL = 1;
    UART_CTRL = 0;
   
}
//UART function to send a string 
void uart_sendline(uint8_t *my_str)
{
    for (uint8_t i = 0; my_str[i] != '\0'; i++)
    {
        uart_send(my_str[i]);
       
    }
}

//UART Receive 
volatile uint32_t uart_receive()
{
	UART_RXCTRL = 1;//enable receiver
   UART_RXCTRL = 0;//disable receiver
   	while(UART_RXSTATUS==0) ;//wait if busy receiving data
    //UART_RXCTRL = 0;//disable receiver
           
   	return UART_RXDATA ;
    
}

uint32_t hex_to_u32(char *buf)
{
    uint32_t val = 0;
    for (int i = 0; i < 8; i++) {
        char c = buf[i];
        val <<= 4;
        if (c >= '0' && c <= '9')
            val |= (c - '0');
        else if (c >= 'a' && c <= 'f')
            val |= (c - 'a' + 10);
        else if (c >= 'A' && c <= 'F')
            val |= (c - 'A' + 10);
    }
    return val;
}

//function to pront hex as ascii in serial terminal
void print_hex(uint32_t data)
{
volatile uint32_t i;
volatile uint32_t  uart_txdata;
  
for(i=0;i<8;i++) //send all 4 byte
  {
  uart_txdata = (data >> (28 - (i * 4))) & 0x0F;  
  volatile uint8_t ascii = byte_to_hex_ascii(uart_txdata);
  uart_send(ascii);//will print byte wise
  delay(1000);
  }
}

//print the BRAM stored data into Serial terminal
    void print_bram(void){
	int index=0; 
    uart_sendline("Printing BRAM content...\n\r");
//print 1st 100 data of Progmem  
    while(bram[index]!=0x00000039){
        print_hex(bram[index]);
       // delay(10);
        uart_sendline("\n\r");
        index=index+1;
    }
//ss_show_word(SS_WORD_DONE);
  //  LED_DATA = 0x00000000;
}
// Driver program to test above function

int main(void)
{
    GPIO_DIR = 0x0000FF00;//gpio8 to 15 set for LEDs

    ss_show_word(SS_WORD_BOOT);  
    uint32_t addr = 0;
    char hex_buf[8];
    int idx = 0;
  LED_DATA = 0x0000FF00;//all LEDs high
 uart_sendline("\n***UART Bootloader Ready***\n\r");
 uart_sendline("\nBootloader V2.0: Copyright: S.K.Maity, School of Electronics Engg., KIIT\n\r");

  while(1){
    
    char c = uart_receive();

        if (c == '\n' || c == '\r') {
            if (idx == 8) {
                uint32_t word = hex_to_u32(hex_buf);
                /* END MARKER */
                if (word == 0xFFFFFFFF) {
                   // LED_DATA = 0x1;   // LED ON
                    uart_sendline("Transfer DONE, Disable boot mode and reset the board...\n\r");
                    print_bram();
                    ss_show_word(SS_WORD_DONE);
                    LED_DATA = 0x00000000;
                    //while (1);        // stop here
                }
                bram[addr] = word;
                addr += 1;
            }
            idx = 0;
        } 
        else {
            if (idx < 8)
                hex_buf[idx++] = c;
        }
    }
  
    

	return 0;
}