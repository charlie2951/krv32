import serial
import time

PORT = "COM5"          # Linux: /dev/ttyUSB0
BAUD = 9600

ser = serial.Serial(PORT, BAUD, timeout=0.1)
time.sleep(2)

print("Connected to UART\n")

with open("output.hex", "r") as f:
    for line in f:
        tx = line.strip()
        if tx:
            ser.write((tx + "\n").encode())
            print("TX:", tx)

        time.sleep(0.1)

        # Read any response from FPGA
        while ser.in_waiting:
            rx = ser.readline().decode(errors="ignore").strip()
            if rx:
                print("RX:", rx)

# Final read after transmission
time.sleep(2)
while ser.in_waiting:
    rx = ser.readline().decode(errors="ignore").strip()
    if rx:
        print("RX:", rx)

print("\nUpload complete")
ser.close()
