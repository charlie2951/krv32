import serial
import time

PORT = "COM5"      # /dev/ttyUSB0 on Linux
BAUD = 9600

ser = serial.Serial(PORT, BAUD, timeout=5)
time.sleep(2)

with open("output.hex", "r") as f:
    for line in f:
        ser.write((line.strip() + "\n").encode())
        time.sleep(0.01)

print("Upload complete")
ser.close()
